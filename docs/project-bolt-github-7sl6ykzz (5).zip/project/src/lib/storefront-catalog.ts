import { supabase } from '@/lib/supabase';
import type { ProductWithInventory } from '@/lib/types';
import { normalizeCatalogSearchQuery, MAX_CATALOG_SEARCH_LENGTH } from '@/lib/commerce-utils';

export interface StorefrontCatalogPage {
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
  items: ProductWithInventory[];
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;
}

function finiteNumber(value: unknown, fallback = 0): number {
  const result = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(result) ? result : fallback;
}

function parseProduct(value: unknown): ProductWithInventory {
  const row = asRecord(value);
  if (!row || typeof row.id !== 'string' || !row.id
      || typeof row.name !== 'string' || typeof row.item_code !== 'string'
      || typeof row.unit !== 'string') {
    throw new Error('وصل سجل كتالوج غير صالح من الخادم؛ لم يُعرض.');
  }

  const displayPrice = finiteNumber(row.display_price, Number.NaN);
  if (!Number.isFinite(displayPrice) || displayPrice < 0) {
    throw new Error('تعذر التحقق من السعر المعتمد لهذا الصنف؛ لم يُعرض سعر بديل.');
  }

  const rawInventory = asRecord(row.inventory);
  const inventory = rawInventory && rawInventory.product_id === row.id
      && typeof rawInventory.warehouse_id === 'string'
    ? {
        id: typeof rawInventory.id === 'string' ? rawInventory.id : '',
        organization_id: typeof rawInventory.organization_id === 'string' ? rawInventory.organization_id : undefined,
        product_id: row.id,
        warehouse_id: rawInventory.warehouse_id,
        quantity_on_hand: finiteNumber(rawInventory.quantity_on_hand),
        quantity_reserved: 0,
        quantity_available: finiteNumber(rawInventory.quantity_available),
      }
    : undefined;

  return {
    id: row.id,
    organization_id: typeof row.organization_id === 'string' ? row.organization_id : undefined,
    name: row.name,
    name_en: typeof row.name_en === 'string' ? row.name_en : null,
    item_code: row.item_code,
    sku: typeof row.sku === 'string' ? row.sku : null,
    barcode: typeof row.barcode === 'string' ? row.barcode : null,
    category_id: typeof row.category_id === 'string' ? row.category_id : null,
    brand_id: typeof row.brand_id === 'string' ? row.brand_id : null,
    unit: row.unit,
    description: typeof row.description === 'string' ? row.description : null,
    image_url: typeof row.image_url === 'string' ? row.image_url : null,
    is_active: row.is_active === true,
    is_featured: row.is_featured === true,
    sort_order: finiteNumber(row.sort_order),
    price_wholesale_of_wholesale: 0,
    price_wholesale: 0,
    price_retail: 0,
    base_price: finiteNumber(row.base_price),
    stock_quantity: finiteNumber(row.stock_quantity),
    reserved_quantity: 0,
    min_stock_level: 0,
    status: typeof row.status === 'string' ? row.status : 'active',
    created_at: typeof row.created_at === 'string' ? row.created_at : '',
    display_price: displayPrice,
    inventory,
  };
}

export async function fetchStorefrontCatalogPage(input: {
  search: string;
  categoryId: string | null;
  page: number;
  pageSize?: number;
  availableOnly: boolean;
}): Promise<StorefrontCatalogPage> {
  const page = Math.max(1, Math.floor(input.page));
  const pageSize = Math.min(100, Math.max(1, Math.floor(input.pageSize ?? 24)));
  const search = normalizeCatalogSearchQuery(input.search).slice(0, MAX_CATALOG_SEARCH_LENGTH);
  const { data, error } = await supabase.rpc('get_storefront_catalog_page', {
    p_search: search,
    p_category_id: input.categoryId,
    p_page: page,
    p_page_size: pageSize,
    p_available_only: input.availableOnly,
  });
  if (error) throw new Error('تعذر تحميل صفحة الكتالوج من الخادم.');
  const payload = asRecord(data);
  if (!payload || !Array.isArray(payload.items)) {
    throw new Error('استجابة صفحة الكتالوج غير صالحة؛ لم تُعرض نتائج غير مؤكدة.');
  }

  const items = payload.items.map(parseProduct);
  const totalCount = finiteNumber(payload.total_count, Number.NaN);
  const totalPages = finiteNumber(payload.total_pages, Number.NaN);
  const resolvedPage = finiteNumber(payload.page, Number.NaN);
  const resolvedPageSize = finiteNumber(payload.page_size, Number.NaN);
  if (![totalCount, totalPages, resolvedPage, resolvedPageSize].every(Number.isFinite)
      || totalCount < 0 || totalPages < 0 || resolvedPage < 1 || resolvedPageSize < 1
      || items.length > resolvedPageSize) {
    throw new Error('بيانات ترقيم صفحات الكتالوج غير صالحة؛ لم تُعرض نتائج غير مؤكدة.');
  }
  return {
    page: resolvedPage,
    pageSize: resolvedPageSize,
    totalCount,
    totalPages,
    items,
  };
}
